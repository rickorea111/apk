package com.example.bloqueador

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var count: TextView
    private val prefs by lazy { getSharedPreferences("prefs", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Bloqueador de Desconhecidos"
            textSize = 24f
        })
        status = TextView(this).apply { textSize = 16f; setPadding(0, pad, 0, pad) }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "1. Permitir acesso aos contatos"
            setOnClickListener {
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 1)
            }
        })
        root.addView(Button(this).apply {
            text = "2. Definir como app de triagem de chamadas"
            setOnClickListener {
                val rm = getSystemService(RoleManager::class.java)
                if (rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
                    !rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
                ) {
                    startActivityForResult(
                        rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 2
                    )
                }
            }
        })

        root.addView(Switch(this).apply {
            text = "Bloqueio ativado"
            isChecked = prefs.getBoolean("enabled", true)
            setPadding(0, pad, 0, pad / 2)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("enabled", v).apply() }
        })
        root.addView(Switch(this).apply {
            text = "Bloquear também números ocultos"
            isChecked = prefs.getBoolean("block_hidden", true)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("block_hidden", v).apply() }
        })

        count = TextView(this).apply { textSize = 16f; setPadding(0, pad, 0, 0) }
        root.addView(count)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        refresh()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun refresh() {
        val contacts = checkSelfPermission(Manifest.permission.READ_CONTACTS) ==
                PackageManager.PERMISSION_GRANTED
        val role = getSystemService(RoleManager::class.java)
            .isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        status.text = (if (contacts) "✔ Contatos: permitido" else "✖ Contatos: pendente") +
                "\n" +
                (if (role) "✔ Triagem de chamadas: ativa" else "✖ Triagem de chamadas: pendente")
        count.text = "Chamadas bloqueadas: ${prefs.getInt("blocked", 0)}"
    }
}
