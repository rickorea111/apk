package com.example.bloqueador

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService

class ScreeningService : CallScreeningService() {

    override fun onScreenCall(details: Call.Details) {
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        val builder = CallResponse.Builder()

        val enabled = prefs.getBoolean("enabled", true)
        val blockHidden = prefs.getBoolean("block_hidden", true)
        val incoming = details.callDirection == Call.Details.DIRECTION_INCOMING
        val hasPermission = checkSelfPermission(Manifest.permission.READ_CONTACTS) ==
                PackageManager.PERMISSION_GRANTED

        if (enabled && incoming && hasPermission) {
            val number = details.handle?.schemeSpecificPart
            val block = if (number.isNullOrBlank()) blockHidden else !isInContacts(number)
            if (block) {
                builder.setDisallowCall(true)
                    .setRejectCall(true)
                    .setSkipNotification(true)
                prefs.edit().putInt("blocked", prefs.getInt("blocked", 0) + 1).apply()
            }
        }
        respondToCall(details, builder.build())
    }

    // Em caso de erro, NÃO bloqueia (retorna true) para não perder chamadas importantes.
    private fun isInContacts(number: String): Boolean = try {
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
        )
        contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)
            ?.use { it.count > 0 } ?: true
    } catch (e: Exception) {
        true
    }
}
